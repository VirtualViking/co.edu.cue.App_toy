package persistence;

public class PersistencePath {
  public static final String TOY_FILE_PATH = "toys.txt";
}
