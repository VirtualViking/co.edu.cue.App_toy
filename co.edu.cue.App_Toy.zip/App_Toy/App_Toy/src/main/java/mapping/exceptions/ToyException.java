package mapping.exceptions;

public class ToyException extends RuntimeException{
    public ToyException(String message){
        super(message);
    }
}
